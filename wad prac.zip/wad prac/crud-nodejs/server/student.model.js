import mongoose from "mongoose";

const StudentSchema = mongoose.Schema({

    name:String,
    wad_marks: Number,
    cc_marks: Number,
    dsbda_marks: Number,
    cns_marks: Number,
    ai_marks: Number,
    rollno:{
        type:Number,
        unique:true
    },

},{timestamps:true});

export const Student = mongoose.model("Student",StudentSchema); 