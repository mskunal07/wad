
document.getElementById("RegistrationFrom")?.addEventListener("submit",(event) => {

    console.log("Entered for submission !!! ");

    event.preventDefault();

    const formData = {
        name:document.getElementById("name").value,
        email:document.getElementById("email").value
    }

    console.log("formdata : ",formData);

    let RegisteredUsers = JSON.parse(localStorage.getItem("users")) || [];

    RegisteredUsers.push(formData);

    localStorage.setItem("users",JSON.stringify(RegisteredUsers));

    window.location.href = "list.html";


})