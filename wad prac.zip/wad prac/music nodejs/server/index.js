import express from "express"
import dotenv from "dotenv"
import bodyParser from "body-parser"
import cors from "cors"
import mongoose from "mongoose"
import { Song } from "./song.model.js"


const app = express();
app.set("view engine","ejs");

dotenv.config({
    path:".env"
})


app.use(express.json())
app.use(bodyParser.urlencoded({extended:true}));
app.use(bodyParser.json());

app.use(cors({
    origin:"*",
    credentials:true
}));

const connectDB = async () => {

    try {
        const connectionInstance = await mongoose.connect(process.env.MONGODB_URI);
        console.log(`Database connected with host id : ${connectionInstance.connection.host}`);
    } catch (error) {
        console.log(error);
    }

};

connectDB();



app.post("/addsong",async(req,res) => {

    const {songName,filmName,musicDirector,singer,actor,actress} = req.body

    console.log("body : ",req.body);

    // if( 
    //     [songName,filmName,musicDirector,singer].some((item) => item.trim() === "")
    // ) {
    //     console.log("all Fields are required ");
    // }

    const createdSongDetails = await Song.create({
        songName,
        filmName,
        musicDirector,
        singer,
        actor,
        actress
    })

    console.log("song created : ",createdSongDetails);

    res.redirect("/displayAllSongDetails");
})

app.post("/getspecifiedmusicdirectorsong", async(req,res) => {

    const {musicDirector} = req.body;

    const targetSong = await Song.find({musicDirector:musicDirector});

    console.log("song found : ",targetSong);

    res.render("tabular.ejs",{songs:targetSong});

} );


app.get("/displayAllSongDetails", async (req,res) => {

    const allSongDetails = await Song.find();

    res.render("tabular.ejs",{songs:allSongDetails});

} );

app.post("/deleteSong",async(req,res) => {

    const{songName} = req.body;

    await Song.findOneAndDelete({songName:songName});

    res.redirect("/displayAllSongDetails");

});

app.get("/update/:song",async(req,res) => {

    const songName = req.params.song;

    console.log("song : ",songName);

    const song = await Song.find({songName:songName});

    res.render("updateForm.ejs",{song:song});

})

app.post("updatesong/",async(req,res) => {

    const {songName,filmName,musicDirector,singer,actor,actress} = req.body

    const targetSong = await Song.find({songName:songName});

    if(!targetSong) {
        console.log("song not found ");
        return res.status(404).json("song not found");
    }

    const updatedSong = await Song.findOneAndUpdate(
        {songName:songName},
        {
            $set:{
                songName,
                filmName,
                musicDirector,
                singer,
                actor,
                actress
            }
        },
        {
            new:true
        }
    );

    console.log("song updated : ",updatedSong);

    res.redirect("/displayAllSongDetails");

})


app.get("/",async(req,res) => {

    res.render("inputForm.ejs");

});

app.get("/searchDirector.ejs",async(req,res) => {
    res.render("searchDirector.ejs");
})




const port = process.env.PORT || 4000;

app.listen(port,(req,res) => {

    console.log("server is listening on port ",port);

});
