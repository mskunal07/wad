
document.getElementById("RegistrationFrom")?.addEventListener("submit",(event) => {

    console.log("Entered for submission !!! ");

    event.preventDefault();

    const formData = {
        name:document.getElementById("name").value,
        email:document.getElementById("email").value
    }


    const xhr = new XMLHttpRequest();
    xhr.open("POST","http://localhost:3000/register",true);
    xhr.setRequestHeader("Content-Type","application/json");

    xhr.onload = function(){

        if(xhr.status === 200) {
            console.log("Registration Successfull");
            window.location.href = "http://localhost:3000/getUsers";
        }
        else {
            console.error("Registration Failed ! ");
        }
    };

    xhr.send(JSON.stringify(formData));


})


// Form.addEventListener("submit", function (event) {
    

// })