import express from "express";
import bodyParser from "body-parser";
import cors from "cors";

const app = express();
app.use(
  cors({
    origin: "*",
    credentials: true,
  })
);

app.use(bodyParser.json());

const RegisteUsersArray = [];

app.post("/register", (req, res) => {
  const { name, email } = req.body;

  if (!name || !email) {
    return res.status(500).json({ error: "Name and Email required" });
  }

  const user = { name, email };
  RegisteUsersArray.push(user);
  console.log(
    RegisteUsersArray.map((user) => ` ${user.name} -- ${user.email} \n`)
  );

  return res
    .status(200)
    .json({ message: "User Registered Successfully !!", name, email });
});

app.get("/getUsers", (req, res) => {
  console.log(
    RegisteUsersArray.map((user) => ` ${user.name} -- ${user.email} \n`)
  );

  res.status(200).send(`
        <h2>List of Registered Users</h2>
        <ul>
            ${RegisteUsersArray.map((user) => `<li>${user.name} - ${user.email}</li>`).join("")}
        </ul>
    `);
});

app.listen(3000, (req, res) => {
  console.log("server is listening on port 3000");
});
