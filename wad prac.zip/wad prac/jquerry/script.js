




$(document).on("swiperight", function (event) {
    if ($.mobile.activePage.attr("id") === "home") {
      $.mobile.changePage("#contact", { transition: "slide", reverse: true });
    } else if ($.mobile.activePage.attr("id") === "about") {
      $.mobile.changePage("#home", { transition: "slide", reverse: true });
    } else if ($.mobile.activePage.attr("id") === "dept") {
      $.mobile.changePage("/about.html", { transition: "slide", reverse: true });
    }
    else if ($.mobile.activePage.attr("id") === "contact") {
      $.mobile.changePage("#dept", { transition: "slide", reverse: true });
    }
  });

  $(document).on("swipeleft", function (event) {
    if ($.mobile.activePage.attr("id") === "home") {
      $.mobile.changePage("/about.html", { transition: "slide" });
    } else if ($.mobile.activePage.attr("id") === "about") {
      $.mobile.changePage("#dept", { transition: "slide" });
    }
    else if ($.mobile.activePage.attr("id") === "dept") {
      $.mobile.changePage("#contact", { transition: "slide" });
    }
    else if ($.mobile.activePage.attr("id") === "contact") {
      $.mobile.changePage("#home", { transition: "slide" });
    }
  });